document.querySelector("#start_chat").addEventListener("click", (event) => {});
